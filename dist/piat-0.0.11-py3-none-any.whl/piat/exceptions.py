# (c) 2019, Ali Aqrabawi <aaqrabawn@gmail.com>
#
# This file is part of Piat
#
# Piat is free software licensed under MIT License.


class PiatError(Exception):
    """
    Piat Exception
    """
    pass
